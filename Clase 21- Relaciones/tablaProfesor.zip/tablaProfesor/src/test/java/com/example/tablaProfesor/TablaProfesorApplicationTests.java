package com.example.tablaProfesor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TablaProfesorApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.Apuestas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApuestasApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApuestasApplication.class, args);
	}

}

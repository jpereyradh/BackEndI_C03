package com.example.tablaMovimientos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TablaMovimientosApplicationTests {

	@Test
	void contextLoads() {
	}

}

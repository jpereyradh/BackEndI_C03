package com.example.tablaMovimientos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TablaMovimientosApplication {

	public static void main(String[] args) {
		SpringApplication.run(TablaMovimientosApplication.class, args);
	}

}

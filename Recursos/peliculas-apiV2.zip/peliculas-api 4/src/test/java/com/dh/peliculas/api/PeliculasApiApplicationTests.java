package com.dh.peliculas.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PeliculasApiApplicationTests {

    @Test
    void contextLoads() {
    }

}

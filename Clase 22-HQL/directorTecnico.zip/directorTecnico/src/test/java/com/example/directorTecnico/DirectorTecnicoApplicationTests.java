package com.example.directorTecnico;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DirectorTecnicoApplicationTests {

	@Test
	void contextLoads() {
	}

}
